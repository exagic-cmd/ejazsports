<div class="card mb-4">
    <div class="card-header">
        <h4>Product Info</h4>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Title</label>
            <input readonly value="{{$productVariant->product->title}}"  type="text" name="scan" id="scan" placeholder="Scan here" class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Barcode</label>
            <input  value="{{$productVariant->barcode}}"  type="text" name="barcode" id="barcode"  class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Shade</label>
            <input  readonly value="{{$productVariant->shade}}"  type="text" name="shade" id="shade"  class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Size</label>
            <input readonly value="{{$productVariant->size}}"  type="text" name="size" id="size"  class="form-control" >
        </div>
    </div>
    
    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Weight</label>
            <input  value="{{$productVariant->product->weight}}"  type="text" name="weight" id="weight"  class="form-control" >
        </div>
    </div>
    
    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Status</label>
            <input readonly  value="{{$productVariant->product->status ? 'ACTIVE' : 'INACTIVE'}}" style="background-color: {{$productVariant->product->status ? 'green' : 'red'}} ; color:white" type="text"  class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Available Qty</label>
            <input readonly value="{{$availableQty}}"  type="text" name="available_qty" id="available_qty" placeholder="Scan here" class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Not Scanned Orders</label>
            <input readonly value="{{$notScanned}}"  type="text"  placeholder="Scan here" class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Audit Qty</label>
            <input    type="text" value="" name="in_hand_qty" id="in_hand_qty" placeholder="Enter here" class="form-control" >
        </div>
    </div>

    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Difference Qty</label>
            <input readonly value="0"  type="text" name="difference_qty" id="difference_qty" placeholder="Scan here" class="form-control" >
        </div>
    </div>
    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Adjust In Stock</label>
            <input onkeyup="updateDiff()"  type="text" value="0" name="adjust_in_stock" id="adjust_in_stock" placeholder="Enter here" class="form-control" >
        </div>
    </div>
    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Adjust In Expiry</label>
            <input onkeyup="updateDiff()"  type="text" value="0" name="adjust_in_expiry" id="adjust_in_expiry" placeholder="Enter here" class="form-control" >
        </div>
    </div>
    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Adjust In Damage</label>
            <input onkeyup="updateDiff()"  type="text" value="0" name="adjust_in_damage" id="adjust_in_damage" placeholder="Enter here" class="form-control" >
        </div>
    </div>
    <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Adjust In Missing</label>
            <input onkeyup="updateDiff()"  type="text" value="0" name="adjust_in_missing" id="adjust_in_missing" placeholder="Enter here" class="form-control" >
        </div>
    </div>
    
     <div class="card-body" style="padding: 0.5rem;">
        <div class="mb-1">
            <label for="product_name" class="form-label">Adjust In Tester</label>
            <input onkeyup="updateDiff()"  type="text" value="0" name="adjust_in_tester" id="adjust_in_tester" placeholder="Enter here" class="form-control" >
        </div>
    </div>
</div>

<input type="hidden" name="product_id" value="{{$productVariant->product_id}}">
<input type="hidden" name="variant_id" value="{{$productVariant->id}}">
